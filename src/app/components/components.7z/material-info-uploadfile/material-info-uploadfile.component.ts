import { Component, OnInit, ViewContainerRef, computed, signal } from '@angular/core';
import { TaskInfoState } from '../task-info/task-info.component';
import { NzFormatEmitEvent, NzTreeNode } from 'ng-zorro-antd/tree';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../../../service/app.service';
import { AdobeService } from '../../../service/@base/adobe.service';
import { ApplyItemInfoVo, FolioItemVo, MaterialApplyVo, TaskUploadRequest, TaskVo } from '../../../service/@vo';
import { NzDropdownMenuComponent } from 'ng-zorro-antd/dropdown';
import { NzModalService } from 'ng-zorro-antd/modal';
import { IUploadFolioItemState, UploadFolioItemComponent } from '../task-info/upload-folio-item/upload-folio-item.component';

@Component({
  selector: 'app-material-info-uploadfile',
  templateUrl: './material-info-uploadfile.component.html',
  styleUrls: ['./material-info-uploadfile.component.css']
})
export class MaterialInfoUploadfileComponent implements OnInit {
  state = signal<TaskInfoState>({});
  request = signal<TaskUploadRequest>({});

  fileName = computed(() => {
    if(this.state().task?.material_apply?.length){
      return this.state().task!.material_apply![0].ma_id;
    }
    return "";
  });

  // ma: MA = {};

  material_apply = computed(() => {
    const ma: MaterialApplyVo = this.state().task?.material_apply?.length
      ? this.state().task!.material_apply![0]
      : {};

    return ma;
  });

  apply_item_info = computed(() => {
    const list = this.state().task?.material_apply?.length
      ? (this.state().task!.material_apply![0].apply_item_info || [])
      : [];

    return list;
  });

  pkgNodes = signal<NzTreeNode[]>([]);

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private viewContainerRef: ViewContainerRef,
    private appService: AppService,
    private adobeService: AdobeService,
    private modalService: NzModalService,
  ) { }

  ngOnInit() {

    this.route.queryParams.subscribe(async p => {
      this.appService.CurPageUrl("main/materialinfo-uploadfile");

      const grp_id = p["grp_id"];
      const task = this.appService.selected_task();

      this.state.set({ grp_id, task });

      this.pkgNodes.set(this.toTree([task]));

      console.log("#", grp_id);
      console.log(task);
    });

  }

  doUploadFile(evt: MouseEvent) {
  }

  goBack = () => {
    const returnUrl = this.appService.GoPrePage();
    this.router.navigate([returnUrl],{ queryParams: {grp_id: this.state().grp_id} });
  };

  toTree(tasks: TaskVo[]){
    let ret: Array<NzTreeNode|any> = [];

    tasks.forEach(x => {
      let children: Array<NzTreeNode|any> = [];

      let n = {
        key: x.grp_id!,
        title: x.grp_name!,
        grp_type: x.grp_type, //Folio || Folder || undefine
        isLeaf: false,
        expanded: true,
        children
      };

      if(x.folio_item?.length){ //增加 folio item
        let fi_children: Array<NzTreeNode|any> = [];

        x.folio_item.forEach(fi => {
          let fn = {
            key: `${x.grp_id}:${fi.item_id}`,
            title: fi.subject,
            isLeaf: true,
          };

          fi_children.push(fn);
        });

        children.push(...fi_children);
      }

      if(x.child?.length){ //增加子 pkg
        const sn = this.toTree(x.child);
        children.push(...sn);
      }

      ret.push(n);
    });

    return ret;
  }

  doSelectedPkg(event: NzFormatEmitEvent) {

  }

  openFolder(evt: any) {

  }

  contextMenu(evt: MouseEvent, menu: NzDropdownMenuComponent) {
  }

  uploadFolioItem(data: TaskVo|FolioItemVo) {

    const dlg = this.modalService.create<UploadFolioItemComponent, IUploadFolioItemState>({
      nzContent: UploadFolioItemComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null,
    });

    dlg.componentInstance?.state.set({
      task: data||{},
      folioItem: {},
    });
    dlg.componentInstance?.request.update(req => {
      return {
        ...req,
        material_apply: {
          ma_id: this.material_apply().ma_id,
          ref_type: this.material_apply().ref_type,
          from_folio_item_id: this.material_apply().from_folio_item_id
        }
      };
    });
    dlg.afterClose.subscribe((ret: TaskVo) => {
      // const task = this.state().task;
      this.state.update(x => {
        return {
          ...x,
          task: ret
        };
      });

      console.log(ret);
    });

    this.appService.Refresh();

  }

  removeFolioItem(item: ApplyItemInfoVo) {
    this.modalService.confirm({nzTitle: '確定要移除該檔案？', nzOnOk: () => {
      const parm = {aii_id: item.aii_id};
      this.adobeService.DeleteApplyItemInfo(parm).subscribe(ret => {
        console.log("response removeFolioItem of material-info-uploadfile:", ret);

        const list = this.apply_item_info().filter(x => x.aii_id !== item.aii_id);
        const task = this.state().task!;

        // task.material_apply![0].apply_item_info ||= [];
        task.material_apply![0].apply_item_info = list;
        this.state.update(m => {
          return {
            ...m,
            task
          }
        });

      });
    }});
  }
  openFolioItem(item: ApplyItemInfoVo) {

    const parm = {item_id: item.ref_uid, is_material_apply:true};
    this.adobeService.OpenFolioItem(parm).subscribe(ret => {

      console.log("response openFolioItem of material-info-uploadfile:", ret);

    });
  }
}
