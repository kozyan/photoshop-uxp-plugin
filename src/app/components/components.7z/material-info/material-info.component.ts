import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { TaskInfoState } from '../task-info/task-info.component';
import { NzFormatEmitEvent, NzTreeNode } from 'ng-zorro-antd/tree';
import { ActivatedRoute, Router } from '@angular/router';
import { AppService } from '../../../service/app.service';
import { AdobeService } from '../../../service/@base/adobe.service';
import { MaterialApplyVo, StepVo, TaskVo } from '../../../service/@vo';
import { NzDropdownMenuComponent } from 'ng-zorro-antd/dropdown';
import { NotifyService, NotifyType } from '../../../service/notify.service';
import { NzModalService } from 'ng-zorro-antd/modal';
import { NzTabChangeEvent, NzTabComponent } from 'ng-zorro-antd/tabs';


@Component({
  selector: 'app-material-info',
  templateUrl: './material-info.component.html',
  styleUrls: ['./material-info.component.css']
})
export class MaterialInfoComponent implements OnInit {
  state = signal<TaskInfoState>({});

  loading = signal(false);

  fileName = computed(() => {
    if(this.state().task?.material_apply?.length){
      return this.state().task!.material_apply![0].ma_id;
    }
    return "";
  });


  material_apply = computed(() => {
    const ma: MaterialApplyVo = this.state().task?.material_apply?.length
      ? this.state().task!.material_apply![0]
      : {};

    return ma;
  });

  apply_item_info = computed(() => {
    const list = this.state().task?.material_apply?.length
      ? (this.state().task!.material_apply![0].apply_item_info || [])
      : [];

    return list;
  });

  currentTask = computed(() => {
    return this.appService.selected_task();
  });

  pkgNodes = signal<NzTreeNode[]>([]);

  message = inject(NotifyService).message;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private appService: AppService,
    private adobeService: AdobeService,
    private modalService: NzModalService,
  ) { }

  ngOnInit() {

    this.route.queryParams.subscribe(async p => {
      this.appService.CurPageUrl("main/materialinfo");

      console.log(p);

      const grp_id = p["grp_id"];
      const task = this.appService.selected_task();

      this.state.set({ grp_id, task });

      this.pkgNodes.set(this.toTree([task]));

      console.log("#", grp_id);
      console.log(task);
    });

  }

  doUploadFile(evt: MouseEvent) {
    const returnUrl = this.appService.CurPageUrl();

    this.router.navigate(["main/materialinfo-uploadfile"],{
      queryParams:{
        returnUrl,
        grp_id: this.state().grp_id,
        ma_id: this.material_apply().ma_id
      }
    });
  }

  goBack = () => {
    const returnUrl = this.appService.GoPrePage();

    this.router.navigate([returnUrl]);
  }

  toTree(tasks: TaskVo[]){
    let ret: Array<NzTreeNode|any> = [];

    tasks.forEach(x => {
      let children: Array<NzTreeNode|any> = [];

      let n = {
        key: x.grp_id!,
        title: x.grp_name!,
        grp_type: x.grp_type, //Folio || Folder || undefine
        isLeaf: false,
        expanded: true,
        children
      };

      if(x.folio_item?.length){ //增加 folio item
        let fi_children: Array<NzTreeNode|any> = [];

        x.folio_item.forEach(fi => {
          let fn = {
            key: `${x.grp_id}:${fi.item_id}`,
            title: fi.subject,
            isLeaf: true,
          };

          fi_children.push(fn);
        });

        children.push(...fi_children);
      }

      if(x.child?.length){ //增加子 pkg
        const sn = this.toTree(x.child);
        children.push(...sn);
      }

      ret.push(n);
    });

    return ret;
  }


  doSelectedPkg(event: NzFormatEmitEvent) {

  }

  openFolder(evt: any) {

  }

  contextMenu(evt: MouseEvent, menu: NzDropdownMenuComponent) {
  }

  uploadFolioItem() {
  }

  doUpdateMaterialApply(){

    this.modalService.confirm({nzTitle: '確定要提交該工作單？', nzOnOk: () => {
      const parm = {
        ma_id: this.material_apply().ma_id,
        actual_apply_qty: this.apply_item_info().length || 0,
        ma_status: "3"
      };
      this.adobeService.UpdateMaterialApply(parm).subscribe(ret => {
        console.log(ret);
        if(ret.data?.success){
          this.message.set({msg:"提交成功!", type: NotifyType.success});
        }else{
          this.message.set({msg:`提交失敗! ${ret.data.message}`, type: NotifyType.error});
        }

        this.appService.Refresh();
      });
    }});
  }

  tabChanged(evt: NzTabChangeEvent){
    console.log("tab changed:", evt);

    if(evt.index === 1){

    }
  }

  onStepSelectChanged(step: StepVo){
    this.currentTask().items?.forEach(x => {
      x.selected = false;

      if(x.tfr_id === step.tfr_id){
        x.selected = step.selected;
      }
    });

    this.appService.Refresh();
  }
}
