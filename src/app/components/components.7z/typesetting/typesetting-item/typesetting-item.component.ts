import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild, ViewContainerRef, computed, effect, signal } from '@angular/core';
import { GroupVo, StepVo, TaskVo, UserAccountVo } from './../../../../service/@vo/index';
import { NzModalModule, NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { EditionInfoComponent, EditionInfoState } from '../edition-info/edition-info.component';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { AppService } from '../../../../service/app.service';
import { firstValueFrom } from "rxjs";

import { parseString, parseStringPromise, Builder, ParserOptions} from "xml2js";
import { MetadataInfoComponent, MetadataInfoState } from '../metadata-info/metadata-info.component';
import { MetadataVo } from '../../../../service/@vo/MetadataVo';
import { LayoutOpeningComponent, LayoutOpeningState, OpenLayoutRequest } from '../layout-opening/layout-opening.component';

import { LayoutSubmitComponent, LayoutSubmitState } from '../layout-submit/layout-submit.component';
import { TaskInfoComponent } from '../../task-info/task-info.component';
import { Router } from '@angular/router';
@Component({
  selector: 'app-typesetting-item',
  templateUrl: './typesetting-item.component.html',
  styleUrls: ['./typesetting-item.component.css'],
})
export class TypesettingItemComponent implements OnInit {

  @ViewChild("dlgEditionInfo",{static:false})
  public readonly editionInfo?: EditionInfoComponent;

  @Output("selectChanged") selectChanged: EventEmitter<TaskVo> = new EventEmitter();
  @Input("task") task?: TaskVo;

  item = signal<TaskVo>({pre_step:[], next_step:[]});
  ma_number = computed(() => {
    if(this.item().material_apply?.length){
      return `(${this.item().material_apply![0].ma_id})`;
    }
    return "";

  });

  constructor(
    private cdr: ChangeDetectorRef,
    private modalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
    private router: Router,
    private appService: AppService,
    private adobeService: AdobeService,
  ) {
    effect(() => {
      const countFolioItems = (task: TaskVo): number => {
        let count = task.folio_item?.length || 0;
        if (task.child) {
          for (const childTask of task.child) {
            count += countFolioItems(childTask);
          }
        }
        return count;
      };
      const totalFolioItems = countFolioItems(this.item());
      this.item().progress_state = totalFolioItems > 0 ? 30 : 0;
    });
  }

  ngOnInit() {
    this.item.set(this.task || {pre_step:[], next_step:[]});
    this.appService.ClearPageUrl(); //起点
    this.appService.CurPageUrl("main/typesetting");
  }

  doSelectItem(){
    this.selectChanged?.emit(this.item());
  }

  goPreference = () => this.router.navigate(["main/preference"],{queryParams:{returnUrl:"main/typesetting"}});

  doShowTaskInfo = (evt: Event) => {
    evt.stopPropagation();

    this.doSelectItem();

    const task = this.item();
    this.appService.selected_task.set(task);

    const returnUrl = this.appService.CurPageUrl();
    if(this.item().material_apply?.length){
      this.router.navigate(["main/materialinfo"],{queryParams:{returnUrl, grp_id: this.item().grp_id}});
    }else{
      this.router.navigate(["main/taskinfo"],{queryParams:{returnUrl, grp_id: this.item().grp_id}});
    }
  };

  ///版心资讯
  layoutInfo = (evt: Event) => {

    evt.stopPropagation();

    //27921
    this.adobeService.DisplayLayoutInfo({ "layout_id" : this.item().layout_id }).subscribe(x => {
      console.log(x);
    });
  };

  ///开版
  open = (evt: Event) => {
    // evt.stopPropagation();

    const dlg = this.modalService.create<LayoutOpeningComponent, LayoutOpeningState>({
      nzContent: LayoutOpeningComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null
    });
    dlg.componentInstance?.state.set({open: true, layout_id: this.item().layout_id, task: this.item()});
    dlg.afterClose.subscribe((x:OpenLayoutRequest) => {
      console.log(x);

      this.item.update(t => {
        return {
          ...t,
          editing: !x?.readonly,
        }
      });

      console.log("开版：", this.item());
      this.appService.Refresh();
    });

    this.appService.Refresh();
  };

  ///排版挂接(修改版心资讯)
  hook = (evt: Event) => {
    // evt.stopPropagation();

    const dlg = this.modalService.create<EditionInfoComponent, EditionInfoState>({
      nzContent: EditionInfoComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null
    });
    dlg.componentInstance?.state.set({open: true, task: this.item()});

    this.appService.Refresh();
  };

  metadata = async (evt: Event) => {
    evt.stopPropagation();

    const ob = this.adobeService.GetPanelInfo({layout_id: this.item().layout_id});
    const ret = await firstValueFrom(ob);
    console.log("GetPanelInfo", ret);

    const strMetadata = ret.data || '<metadata><self><direct></self></metadata>';

    const meta = await parseStringPromise(strMetadata, {explicitArray: false}) as MetadataVo;
    console.log("xml to json", meta);

    const dlg = this.modalService.create<MetadataInfoComponent, MetadataInfoState>({
      nzContent: MetadataInfoComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null
    });
    dlg.componentInstance?.state.set({
      open: true,
      layout_id: this.item().layout_id,
      data: meta
    });

    this.appService.Refresh();
  };

  goPrev = (evt: Event, step: StepVo, user?: UserAccountVo, group?: GroupVo) => {
    evt.stopPropagation();

    console.log("go prev", step);

    const dlg = this.modalService.create<LayoutSubmitComponent, LayoutSubmitState>({
      nzContent: LayoutSubmitComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null,
    });

    dlg.componentInstance?.state.set({
      open: true,
      layout_id: this.item().layout_id,
      task: this.task,
      step: step,
      group,
      user
    });

    this.appService.Refresh();
  };
  goNext = async (evt: Event, step: StepVo, user?: UserAccountVo, group?: GroupVo) => {
    evt.stopPropagation();

    console.log("go next:", step);

    const dlg = this.modalService.create<LayoutSubmitComponent, LayoutSubmitState>({
      nzContent: LayoutSubmitComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null,
    });

    dlg.componentInstance?.state.set({
      open: true,
      layout_id: this.item().layout_id,
      task: this.task,
      step: step,
      group,
      user
    });

    this.appService.Refresh();

  };

  stepName = (step: StepVo) => {
    return step.model_name === 'Composer' && step.model_func_name === 'FinalSubmit'
      ? "交清樣" : step.step_name;
  };
}
