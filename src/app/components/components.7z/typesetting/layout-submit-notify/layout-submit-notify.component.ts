import { Component, OnInit, ViewContainerRef, signal } from '@angular/core';
import { MailVo, SubmitLayoutResponse } from '../../../../service/@vo/SubmitLayoutResponse';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { AppService } from '../../../../service/app.service';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { TaskVo } from '../../../../service/@vo';

export interface SubmitLayoutNotifyState {
  open: boolean;
  task?: TaskVo;
  response?: SubmitLayoutResponse;
}

export interface SubmitLayoutRequest {
  send_email: boolean;
  mail: MailVo,
  selectedUserIds: Array<string>
}

@Component({
  selector: 'app-layout-submit-notify',
  templateUrl: './layout-submit-notify.component.html',
  styleUrls: ['./layout-submit-notify.component.css']
})
export class LayoutSubmitNotifyComponent implements OnInit {

  state = signal<SubmitLayoutNotifyState>({open: false});

  request = signal<SubmitLayoutRequest>({
    send_email: true,
    mail:{body:"", subject:"", to_users:[], },
    selectedUserIds:[]
  });

  constructor(
    private modal: NzModalRef,
    private adobeService: AdobeService,
    private appService: AppService) { }

  ngOnInit() {
    this.request.mutate(req => {
      req.mail = this.state().response?.mail || {body:"", subject:"", to_users:[]};
      req.selectedUserIds = req.mail?.to_users?.map(x => x.user_id) || [];
    });
  }

  doClose(){
    this.modal.close();
    this.appService.Refresh();
  }

  async doSure(evt: Event) {

    const selectedUserIds = this.request().selectedUserIds;
    const parm = {
      layout_id: this.state().task?.layout_id,
      subject: this.request().mail.subject,
      body: this.request().mail.body,
      to_users: this.request().mail.to_users.filter(x => selectedUserIds.includes(x.user_id))
    };
    console.log(parm);

    if(this.request().send_email){
      this.adobeService.SendMail(parm);
    }

    this.modal.close(parm);
    this.appService.Refresh();
  }
}
