import { Component, Input, OnInit, computed, effect, signal } from '@angular/core';
import { TaskVo } from '../../../../service/@vo';
import { AppService } from '../../../../service/app.service';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { firstValueFrom } from 'rxjs';

export interface EditionInfoState {
  open: boolean;
  task?: TaskVo;
}

@Component({
  selector: 'app-edition-info',
  templateUrl: './edition-info.component.html',
  styleUrls: ['./edition-info.component.css']
})
export class EditionInfoComponent implements OnInit {

  state = signal<EditionInfoState>({open: false});

  fileName = computed(() => {
    const name = (this.state().task?.progress_state || 0) >= 10
      ? `${this.state().task?.filename}.indd`
      : this.state().task?.filename;
    return name;
  });

  save_path = computed(() => {
    return this.appService.pluginInfo().localPath;
  });

  constructor(
    private modal: NzModalRef,
    private appService: AppService,
    private adobeService: AdobeService,
  ) {
    effect(() => {
      console.log("the state:", this.state());
    });
  }

  async ngOnInit() {

  }

  doClose(){
    this.state.mutate(val => val.open = false);
    this.modal.close();
    this.appService.Refresh();
  }

  doSure(evt: Event) {
    this.adobeService.ModifyLayoutInfo({layout_id: this.state().task?.layout_id});
    this.modal.close();
  }
}
