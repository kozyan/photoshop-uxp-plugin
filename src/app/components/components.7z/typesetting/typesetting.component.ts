import { ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, OnDestroy, OnInit, ViewChild, effect, inject, signal } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { Router } from '@angular/router';
import { AdobeService } from '../../../service/@base/adobe.service';
import { AppService } from '../../../service/app.service';
import { ITaskVo, StepVo, TaskRequest, TaskVo } from '../../../service/@vo';
import { switchMap, throttle } from 'rxjs/operators';
import { NzTabChangeEvent, NzTabComponent } from 'ng-zorro-antd/tabs';
import { interval, debounceTime, BehaviorSubject } from 'rxjs';
import { NarPkgClassVo } from '../../../service/@vo/NarPkgClassVo';
import { Subject } from 'rxjs';
import { NzModalService } from 'ng-zorro-antd/modal';
import { AppContext } from '../../../core/app.context';

@Component({
  selector: 'app-typesetting',
  templateUrl: './typesetting.component.html',
  styleUrls: ['./typesetting.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TypesettingComponent implements OnInit {
  @ViewChild('typesettingList', { static: false }) typesettingList?: ElementRef;

  loading = signal(false);

  tasks = inject(AppService).tasks;
  currentTask = inject(AppService).selected_task;
  tasksChanged$ = toObservable(this.tasks);

  activities_request = inject(AppService).activity_request;
  activities_query$ = toObservable(this.activities_request);

  task_request = inject(AppService).task_request;
  task_request$ = toObservable(this.task_request);

  pkg_list = inject(AppService).pkg_list;
  selectedPkg = signal<NarPkgClassVo>({});

  folio_item_path = signal<{item_id?: string, grp_id?: string}>({});

  selectedTabIndex = 0;

  constructor(
    private cd: ChangeDetectorRef,
    private router: Router,
    private adobeService: AdobeService,
    private appService: AppService,
    private modalService: NzModalService,
  ) {

    effect(() => {
      this.activities_request.set({layout_id: this.currentTask().layout_id});
    }, {allowSignalWrites:true});
  }

  ngOnInit() {
    this.loading.set(true);

    const tr = AppContext.getProjectCache<TaskRequest>("task_request");
    if(tr){
      this.task_request.mutate(r => r.pkg_class_id = tr.pkg_class_id);
    }


    this.adobeService.onDocChange().subscribe(ret => {
      // 当在 task list 页面时，若发生 onDocChange 事件，则自动打开当前 task 的 folio_item
      console.log("open folio_item:", ret.data);

      const {item_id, path} = ret.data;
      const arr = path.split(":");
      const grp_id = arr[0];
      this.folio_item_path.set({item_id, grp_id: grp_id});

      if (this.tasks().length) {
        this.navigate_to_folio_item(this.tasks(), grp_id, item_id);
      }
    });

    this.tasksChanged$
    .subscribe(tasks => {
      console.log("tasks changed -> task list:", tasks);
      this.loading.set(false);

      const {item_id, grp_id} = this.folio_item_path();
      this.navigate_to_folio_item(tasks, grp_id, item_id);

    });

    this.adobeService.GetNarPkgClass().subscribe(x => {
      console.log(x);
      this.pkg_list.set(x.data as NarPkgClassVo[] || []);
    });
    // this.doGetTaskList();

    this.activities_query$
    // .pipe(throttle(() => interval(1000)))
    .pipe(switchMap(p => this.adobeService.GetLayoutFolwRecord(p)))
    .subscribe(x => {
      console.log(x);

      this.currentTask.mutate(xx => xx.items = (x.data.items || []));

      this.loading.set(false);

      this.refresh();
    });

    this.task_request$
    .pipe(debounceTime(1000))
    .pipe(switchMap(p => this.adobeService.GetTaskList(p)))
    .subscribe(x => {
      console.log(x);
      this.tasks.set(x.data as TaskVo[] || []);

      this.loading.set(false);

      this.refresh();
    });
  }

  doGetTaskList = () => {
    this.loading.set(true);

    const req = this.task_request();
    this.task_request.set({
      ...req,
      pkg_class_id: req.pkg_class_id || undefined
    });

    AppContext.setProjectCache("task_request", this.task_request());
  };

  private navigate_to_folio_item(tasks: Partial<ITaskVo>[], grp_id: string | undefined, item_id: string | undefined) {
    const task = tasks.find(x => x.grp_id === grp_id);

    if (task) {
      this.appService.selected_task.set(task);

      const returnUrl = this.appService.CurPageUrl();
      if (task.material_apply?.length) {
        this.router.navigate(["main/materialinfo"], { queryParams: { returnUrl, grp_id: task.grp_id, item_id } });
      } else {
        this.router.navigate(["main/taskinfo"], { queryParams: { returnUrl, grp_id: task.grp_id, item_id } });
      }

      this.appService.Refresh();
    } else if (grp_id) {
      this.appService.selected_task.set({});
      this.modalService.warning({
        nzTitle: "未找到Task工作單",
        nzContent: "無法定位到當前打開檔案",
      });
    }
  }

  refresh(){
    this.cd.detectChanges();
  }

  goPreference = () => this.router.navigate(["main/preference"],{queryParams:{returnUrl:"main/typesetting"}});

  onTaskSelectChanged(task: TaskVo){
    this.tasks().forEach(x => {
      x.selected = false;

      if(x.grp_id === task.grp_id){
        x.selected = true;
      }
    });

    this.currentTask.set(task);

    this.appService.Refresh();
  }

  onStepSelectChanged(step: StepVo){
    this.currentTask().items?.forEach(x => {
      x.selected = false;

      if(x.tfr_id === step.tfr_id){
        x.selected = step.selected;
      }
    });

    this.appService.Refresh();
  }

  tabChanged = (tab: NzTabChangeEvent) => {
    console.log("tab changed:", tab);

    if(tab.tab.nzTitle !== "Tasks") return;

    const itemId = `layout_item_${this.currentTask().layout_id}`;
    // 新增：滚动到指定锚点
    setTimeout(() => {
      const element = this.typesettingList?.nativeElement?.querySelector("#" + itemId);
      if (element) {
        element.scrollIntoView({
          behavior: 'smooth',
          block: 'nearest',
          inline: 'start'
        });
      }
    }, 100); // 延迟100ms确保DOM更新
  };

}
