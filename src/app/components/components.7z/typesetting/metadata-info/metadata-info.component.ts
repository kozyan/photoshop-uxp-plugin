import { Component, OnInit, computed, signal } from '@angular/core';
import { Entity, LangVo, MetadataVo } from '../../../../service/@vo/MetadataVo';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { AppService } from '../../../../service/app.service';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { Hash } from '../../../../dto/Hash';
import { Builder } from 'xml2js';

export interface MetadataInfoState {
  open: boolean;
  layout_id?: number;
  data?: MetadataVo;
}

@Component({
  selector: 'app-metadata-info',
  templateUrl: './metadata-info.component.html',
  styleUrls: ['./metadata-info.component.css']
})
export class MetadataInfoComponent implements OnInit {

  state = signal<MetadataInfoState>({open: false});
  metaItems = computed(() => {
    const list = this.state().data?.metadata.self.direct.data || [];

    list.forEach(di => di.value_data.sort((al, bl) => al.$.language_code.localeCompare(bl.$.language_code)))

    return list;
  });
  firstMetaItem = computed(() => {
    const items = this.metaItems();
    return items?.length > 0 ? items[0] : undefined;
  });

  column_name_map: Hash<string> = {
    'zh-cn': "简体",
    'zh-tw': "繁體",
    'en-us': "English"
  };

  constructor(
    private modal: NzModalRef,
    private appService: AppService,
    private adobeService: AdobeService,
  ) { }

  ngOnInit() {
  }

  filterLang = (item: Entity<LangVo>) => {
    return item.$.language_code === this.appService.pluginInfo().language_code;
  };

  doClose(){
    this.state.mutate(val => val.open = false);
    this.modal.close();
    this.appService.Refresh();
  }

  doSure(evt: Event) {

    //const data = this.state().data!;
    //data.metadata.$ = {layout_id: this.state().layout_id!};

    this.state.mutate(x => {
      x.data!.metadata.$ = {layout_id: this.state().layout_id!};
    });

    console.log(this.state().data);

    const builder = new Builder({headless: true});
    const str = builder.buildObject(this.state().data);
    // console.log("object ot xml:", str);

    this.adobeService.SaveLayoutMetadata(str); //notify plugins

    this.modal.close();
    this.appService.Refresh();
  }

  doValueChanged(val: string, list: Entity<LangVo>[]) {
    list.forEach(x => { x.$.value = val; });
  }
}
