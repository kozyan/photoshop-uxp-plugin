import { Component, EventEmitter, Input, OnInit, Output, computed, signal } from '@angular/core';
import { StepVo, TaskVo } from '../../../../service/@vo';

@Component({
  selector: 'app-activity-item',
  templateUrl: './activity-item.component.html',
  styleUrls: ['./activity-item.component.css']
})
export class ActivityItemComponent implements OnInit {

  @Output("selectChanged") selectChanged: EventEmitter<StepVo> = new EventEmitter();
  @Input("task") task?: TaskVo;
  @Input("step") step: StepVo = {};

  item = signal<StepVo>({});
  fileName = computed(() => {
    const name = (this.item().progress_state || 0) >= 10
      ? `${this.task?.filename}.indd`
      : this.task?.filename;
    return name;
  });
  constructor() { }

  ngOnInit() {
    this.item.set(this.step);
  }

}
