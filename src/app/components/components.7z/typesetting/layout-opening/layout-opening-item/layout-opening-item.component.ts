import { Component, EventEmitter, Input, OnInit, Output, signal } from '@angular/core';
import { FolioItemVo, LayoutVo, TaskVo } from '../../../../../service/@vo';

@Component({
  selector: 'app-layout-opening-item',
  templateUrl: './layout-opening-item.component.html',
  styleUrls: ['./layout-opening-item.component.css']
})
export class LayoutOpeningItemComponent implements OnInit {

  @Output() selectChanged: EventEmitter<FolioItemVo> = new EventEmitter();
  @Output() selectTemplate: EventEmitter<FolioItemVo> = new EventEmitter();

  @Input() task?: TaskVo;
  @Input() layoutItem: FolioItemVo = {};
  @Input() isHistory: boolean = false;

  item = signal<FolioItemVo>({});

  constructor() { }

  ngOnInit() {
    // this.layoutItem.extension = (this.task?.progress_state || 0) > 0 ? '.indd':'';
    this.item.set(this.layoutItem);
  }

  doSelectTemplate(evt: Event) {
    evt.stopPropagation();
    // this.selectTemplate.emit(this.layoutItem);
  }
  doSelectItem(evt: Event) {
    // if(!this.isHistory) {
    //   evt.stopPropagation();
    //   return;
    // }

    this.layoutItem.selected = true;
    this.selectChanged.emit(this.layoutItem);
  }
}
