import { Component, OnInit, WritableSignal, computed, effect, inject, signal } from '@angular/core';
import { LayoutVo } from '../../../../service/@vo/LayoutVo';
import { TaskVo } from '../../../../service/@vo';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { AppService } from '../../../../service/app.service';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { toObservable } from '@angular/core/rxjs-interop';
import { of, single, switchMap } from 'rxjs';
import { NzTabChangeEvent } from 'ng-zorro-antd/tabs';

export interface LayoutOpeningState {
  open: boolean;
  layout_id?: number;
  task?: TaskVo;
  oldVersionLayoutList?: Array<LayoutVo>;
  templateLayoutList?: Array<LayoutVo>;
}

export interface OpenLayoutRequest {
  layout_id?: number;
  serverFile?: string;
  isOldVersion?: boolean;
  isTemplate?: boolean;
  readonly: boolean;
}

@Component({
  selector: 'app-layout-opening',
  templateUrl: './layout-opening.component.html',
  styleUrls: ['./layout-opening.component.css']
})
export class LayoutOpeningComponent implements OnInit {

  tasks = inject(AppService).tasks;

  loading = signal(false);
  state = signal<LayoutOpeningState>({open: false},{equal:(a, b) => a.layout_id === b.layout_id});

  fileName = computed(() => {
    const name = (this.state().task?.progress_state || 0) >= 10
      ? `${this.state().task?.filename}.indd`
      : this.state().task?.filename;
    return name;
  });

  openLayoutReq = signal<OpenLayoutRequest>({
    serverFile: "",
    isOldVersion: false,
    isTemplate: true,//默认模板打开
    readonly: false
  });

  selectedTabIndex = signal(0);//默认模板打开
  allowToOpenLayout = computed(() => {
    if(this.openLayoutReq().isTemplate){ //选择模板
      const selectedIdx = (this.state().templateLayoutList || []).findIndex(x => x.selected);
      return selectedIdx > -1;
    }

    return true;
  });

  constructor(
    private modal: NzModalRef,
    private appService: AppService,
    private adobeService: AdobeService
  ) {
  }

  ngOnInit() {
    this.adobeService.BrowseOldVersion({layout_id: this.state().layout_id}).subscribe(x => {
      console.log("BrowserOldVersion", x);
      this.state.mutate(s => s.oldVersionLayoutList = (x.data || []));
    });

    this.adobeService.BrowseTemplate({layout_id: this.state().layout_id}).subscribe(x => {
      console.log("BrowseTemplate", x);
      this.state.mutate(s => s.templateLayoutList = (x.data || []));
    });

    this.selectedTabIndex.set(+(this.state().task?.progress_state||0) === 0 ? 0:1);

    this.openLayoutReq.mutate(x => {
      x.layout_id = this.state().layout_id;
      x.isTemplate = this.selectedTabIndex() === 0; //根据 tab 校正请求参数
      x.readonly = this.selectedTabIndex() === 2; //使用以前版本时，默认为只读
    });
  }

  doClose(){
    this.state.mutate(val => val.open = false);
    this.modal.close();
    this.appService.Refresh();
  }

  doSure(evt: Event) {
    const parm = this.openLayoutReq();
    console.log(parm);

    this.adobeService.OpenLayout(parm).subscribe(x => {
      console.log(x);

        this.adobeService.GetLayoutList().subscribe(xl => {
          console.log("layout-opening:GetLayoutList", xl);

          const list = xl.data as TaskVo[] || [];
          const task = list.find(t => t.layout_id === parm.layout_id);
          if(task){
            task!.editing = true;
          }

          this.tasks.set(list);

          this.modal.close(this.openLayoutReq());//将参数返回给 typesetting-item

          this.appService.Refresh();
        });
    });

    //NOTE: 可能会存在 bug，因为如果 OpenLayout 被阻塞了，setTimeout 会先执行，layout 的开版状态就没更新到
    // setTimju
  }

  doHisSelectChanged(evt: LayoutVo) {
    this.state().oldVersionLayoutList?.forEach(x => {
      if(x.fullName === evt.fullName){
        x.selected = evt.selected;

        this.openLayoutReq.mutate(r => {
          r.isOldVersion = true;
          r.serverFile = `${x.fullName}`;
        });
      }else{
        x.selected = false;
      }
    });
  }

  doTabChanged(tab: NzTabChangeEvent) {
    if(tab.index === 0){ //模板

      this.openLayoutReq.mutate(x => {
        x.isTemplate = true;
        x.isOldVersion = false;
        x.readonly = false;
      });
    }else if(tab.index === 1){ //当前版本
      this.openLayoutReq.mutate(x => {
        x.isTemplate = false;
        x.isOldVersion = true;
        x.readonly = false;
      });
    }else{ //历史版本
      this.openLayoutReq.mutate(x => {
        x.isTemplate = false;
        x.isOldVersion = true;
        x.readonly = true;
      });

    }

    this.selectedTabIndex.set(tab.index || 0);
  }

  doSelectTemplate(evt: LayoutVo){


    this.state().templateLayoutList?.forEach(x => {
      if(x.fullName === evt.fullName){
        x.selected = true;
      }else{
        x.selected = false;
      }
    });

    this.openLayoutReq.update(v => {
      return {
        ...v,
        isTemplate: true,
        serverFile: evt.fullName || "",
      }
    });

    this.appService.Refresh();
  }

  async doBrowseTemplateFile(evt: LayoutVo) {

    const ret = window.cep.fs.showOpenDialogEx(false, false, "選擇模板", evt.fullName||"~/Documents", ["indt","indd"],"Template(*.indt;*.indd)","OK");
    if(ret.data && ret.data.length > 0){

      console.log(ret.data);

      this.state().templateLayoutList?.forEach(x => {
        if(x.fullName === evt.fullName){
          x.selected = true;
          x.fullName = ret.data[0];
        }else{
          x.selected = false;
        }
      });

     evt.fullName = ret.data[0];

     this.openLayoutReq.mutate(x => {
        x.isTemplate = true;
        x.serverFile = evt.fullName || "";
      });

      this.appService.Refresh();

    }
  }
}
