import { Component, Injector, OnInit, ViewContainerRef, WritableSignal, computed, effect, inject, signal } from '@angular/core';
import { GeneralSettingVo, GroupVo, StepVo, TaskVo, UserAccountVo } from '../../../../service/@vo';
import { NzModalRef, NzModalService} from 'ng-zorro-antd/modal';
import { AppService } from '../../../../service/app.service';
import { MockData } from '../../../../mock/SubmitComplete.data';
import { LayoutSubmitNotifyComponent } from '../layout-submit-notify/layout-submit-notify.component';
import { SubmitLayoutResponse } from '../../../../service/@vo/SubmitLayoutResponse';
import { firstValueFrom } from 'rxjs';
import { AdobeService } from '../../../../service/@base/adobe.service';

export interface LayoutSubmitState {
  open: boolean;
  layout_id?: number;
  step?: StepVo;
  task?: TaskVo;
  user?: UserAccountVo;
  group?: GroupVo;
}

export interface LayoutSubmitRequest {
  saved?: boolean;
  pdf_lores: boolean;
  pdf_hires: boolean;
  packaging: boolean;
  background: boolean;
}

@Component({
  selector: 'app-layout-submit',
  templateUrl: './layout-submit.component.html',
  styleUrls: ['./layout-submit.component.css']
})
export class LayoutSubmitComponent implements OnInit {

  loading = signal(false);
  state = signal<LayoutSubmitState>({open: false},{equal:(a, b) => a.layout_id === b.layout_id});
  isSubmitFinal = computed(() => {
      return this.state().step?.model_name === 'Composer' && this.state().step?.model_func_name === 'FinalSubmit'
  });

  submitLayoutReq = signal<LayoutSubmitRequest>({
    pdf_hires: false,
    pdf_lores: false,
    packaging: false,
    background: false
  });

  settings: WritableSignal<GeneralSettingVo> = inject(AppService).settings;
  lastSubmitReq: WritableSignal<LayoutSubmitRequest> = inject(AppService).layout_submit_request;

  tasks = inject(AppService).tasks;

  constructor(
    private modal: NzModalRef,
    private appService: AppService,
    private adobeService: AdobeService,
    private mock: MockData,
    private modalService: NzModalService,
    private viewContainerRef: ViewContainerRef,
  ) {
  }

  ngOnInit() {
    this.submitLayoutReq.update(x => {
      //从用户设定缓存中取
      if(this.lastSubmitReq().saved){
        x = this.lastSubmitReq();
      }

      //更新特别属性
      if(!this.isSubmitFinal()){
        x.pdf_lores = true;
      }

      return {...x};
    });
  }

  doClose(){
    this.state.mutate(val => val.open = false);
    this.modal.close(this.submitLayoutReq());
    this.appService.Refresh();
  }

  async doSure(evt: Event) {

    //交版或交清样
    const parm = {
      layout_id: this.state().layout_id,
      layout_name: this.state().task?.name,
      hipdf: this.submitLayoutReq().pdf_hires,
      lopdf: this.submitLayoutReq().pdf_lores,
      packaged: this.submitLayoutReq().packaging,
      background: this.submitLayoutReq().background,
      step: this.state().step,
      res_id: this.state().user?.user_id,
      res_name: this.state().user?.user_name,
      group_id: this.state().group?.group_id,
      group_name: this.state().group?.group_name
    };

    // const ob = this.mock.LayoutSubmitCompleted();
    // let ret = await firstValueFrom(ob);

    this.adobeService.Submit(parm).subscribe(ret => {

      const str = JSON.stringify(ret.data || {});
      const resp = JSON.parse(str);

      const dlg = this.modalService.create<LayoutSubmitNotifyComponent, SubmitLayoutResponse>({
        nzContent: LayoutSubmitNotifyComponent,
        nzViewContainerRef: this.viewContainerRef,
        nzClosable: false,
        nzFooter: null
      });
      dlg.componentInstance?.state.set({
        open: true,
        task: this.state().task,
        response: resp,
      });

      dlg.afterClose.subscribe(x => {

        this.adobeService.GetLayoutList().subscribe(xl => {
          console.log("layout-submit:GetLayoutList", xl);
          console.log("layout-submit-notify:afterClose", x);

          const list = xl.data as TaskVo[] || [];
          const task = list.find(t => t.layout_id === x.layout_id);
          if(task){
            task!.editing = true;
          }

          this.tasks.set(list);

          this.appService.Refresh();
        });

        this.modal.close();
        this.appService.Refresh();
      });

      //缓存用户当前设定
      this.lastSubmitReq.update(x => {
        return {
          saved: true,
          ...this.submitLayoutReq(),
        }
      });

      this.appService.Refresh();
    });

  }
}
