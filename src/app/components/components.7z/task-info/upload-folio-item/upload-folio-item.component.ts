import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ApplyItemInfoVo, FolioItemVo, MaterialApplyVo, TaskFolioResDtlVo, TaskUploadRequest, TaskVo, TreeNodeVo, UserAccountVo } from '../../../../service/@vo';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { AppService } from '../../../../service/app.service';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { NzTreeNode } from 'ng-zorro-antd/tree';
import { UserGroupVo } from '../../../../models/user_group';
import { NotifyService, NotifyType } from '../../../../service/notify.service';

export interface IUploadFolioItemState {
  task: TaskVo,
  folioItem: FolioItemVo
}
type UploadFolioItemState = Required<IUploadFolioItemState>;


@Component({
  selector: 'app-upload-folio-item',
  templateUrl: './upload-folio-item.component.html',
  styleUrls: ['./upload-folio-item.component.css']
})
export class UploadFolioItemComponent implements OnInit {

  state = signal<UploadFolioItemState>({task:{}, folioItem:{} });
  request = signal<TaskUploadRequest>({});
  taskFolioResDtl = signal<Array<TaskFolioResDtlVo>>([]);

  message = inject(NotifyService).message;

  handler = signal<any[]>([]);

  cur_task = computed(() => {
    return this.state().task || {
      filename: "",
      file_info: ""
    };
  });

  sss = computed(() => {
    return this.state().folioItem.res_id || this.state().folioItem.group_id;
  });

  selectedHandler = signal("");
  uploading = signal(false);

  frd_list: Array<TaskFolioResDtlVo> = [];

  constructor(
    private modal: NzModalRef,
    private appService: AppService,
    private adobeService: AdobeService,
  ) { }

  ngOnInit() {

    //新建一个 folio_item
    this.request.update(req => {
      return {
        ...req,
        grp_id: this.state().task.grp_id,
        folder_id: this.state().task.folder_id,
        folio_id: this.state().task.folio_id,
        location_id: this.state().task.location_id,
        ft_id: this.state().task.ftId,
      }
    });

    //如果是打开旧的 folio_item
    if(this.state().folioItem.item_id){
      this.request.update(req => {
        return {
          ...req,
          grp_id: this.state().folioItem.grpId,
          c_abstract: "",
          subject: this.state().folioItem.subject,
          tfr_id: this.state().folioItem.tfr_id,
          folder_id: this.state().folioItem.folio_id,
          folio_id: this.state().folioItem.folio_id,
          planitem_id: this.state().folioItem.planitem_id,
          ft_id: this.state().folioItem.ftId,
          location_id: this.state().folioItem.location_id,
          res_id: this.state().folioItem.res_id,
          res_name: this.state().folioItem.res_name,
          group_id: this.state().folioItem.group_id,
          group_name: this.state().folioItem.group_name,
        }
      });
    }

  }

  doStepChanged(tfr_id: string){

    const parm = {tfr_id: this.request().tfr_id};
    this.adobeService.GetTaskFolioResDtl(parm).subscribe(ret => {
      console.log(ret);

      if(ret.data.length){
        this.frd_list = ret.data as Array<TaskFolioResDtlVo>;

        const node_list: Array<TreeNodeVo> = [];

        this.frd_list.forEach((current, idx) => {
          if(current.user){
            if(!node_list.some(item => item.key === current.user?.user_id)){
              node_list.push({
                key: current.user.user_id,
                title: current.user.user_name,
                isLeaf: true,
                data: current.user
              });
            }
          }else if(current.group){
            if(!node_list.some(item => item.key === current.group?.group_id)){

              const children: Array<TreeNodeVo> = [];
              if(current.group.users?.length){
                current.group.users.forEach(u => {
                  children.push({
                    key: u.user_id,
                    title: u.user_name,
                    isLeaf: true,
                    data: u
                  });
                });
              }

              node_list.push({
                key: current.group.group_id,
                title: current.group.group_name,
                isLeaf: false,
                expanded: true,
                data: current.group,
                children
              });
            }

          }
        });
        this.handler.set(node_list);

        // console.log(data);

        this.selectedHandler.set("");
      }
    });

    //更新 ft_id
    const tfr = this.state().task.task_folio_resources?.find(x => x.tfr_id === tfr_id);
    this.request.update(req => {
      return {
        ...req,
        ft_id: tfr?.ft_id,
      }
    });
  }

  /**
   * @deprecated 该方法已经作废
   *
   * @param {Array<TaskFolioResDtlVo>} list
   * @return {*}
   * @memberof UploadFolioItemComponent
   */
  toTreeNodeList(list: Array<TaskFolioResDtlVo>){
    const ret: Array<TreeNodeVo> = [];

    list.forEach(x => {
      const children: Array<TreeNodeVo> = [];

      if(x.user_list?.length){
        x.user_list.forEach(u => {
          children.push({
            key: u.user_id,
            title: u.user_name,
            isLeaf: true,
            data: u
          });
        });
      }

      ret.push({
        key: x.hr_id?.toString(),
        title: x.hr_name,
        expanded: true,
        children: children,
        data: x
      });
    });

    return ret;
  }

  doClose(parm?: any){
    this.modal.close(parm);
    this.appService.Refresh();
  }

  /**
   *确定上传后 api 会返回空值，并触发 DocChange 事件
   *所以要在 DocChange 的事件中获取以下信息：
   * fileName: "illustrator测试.ai", is_material_apply: false, item_id: "6251838A-4825-443A-9297-E36E2D77A0D9"
   *
   * @param {Event} event
   * @memberof UploadFolioItemComponent
   */
  doSure(event: Event){

    console.log(this.request());

    const parm: TaskUploadRequest = this.request();

    this.uploading.set(true);
    this.appService.Refresh();

    if(!this.request().subject){
      this.message.set({msg:`名稱必填`, type: NotifyType.worning});
      this.uploading.set(false);
      return;
    }
    if(!this.request().ft_id){
      this.message.set({msg:`狀態必填`, type: NotifyType.worning});
      this.uploading.set(false);
      return;
    }
    if(!this.request().res_id && !this.request().group_id){
      this.message.set({msg:`辦理人必填`, type: NotifyType.worning});
      this.uploading.set(false);
      return;
    }

    this.adobeService.Upload(parm).subscribe(ret => {
      console.log("response Upload folio item: ", ret);

      this.uploading.set(false);

      let list = ret.data ? [ret.data] as Array<FolioItemVo | ApplyItemInfoVo> : [];

      const rootTask = this.appService.selected_task();
      const task = this.state().task;

      if(task.material_apply?.length){
        task.material_apply[0].apply_item_info = [...list];

        // this.appService.selected_task.set(task);

        this.state.update(x => {
          return {
            ...x,
            task
          }
        });
        console.log("upload-folio-item:doSure:material apply: ", task);
        this.doClose(task);
      }else{
        //find folio
        const folio = this.findFolio(this.request().folio_id!, rootTask);

        list = list.filter(fi => !rootTask.folio_item?.find(xx => xx.item_id === fi.item_id));

        if(folio){
          folio.folio_item = folio.folio_item || [];

          folio.folio_item.push(...list);

          this.appService.selected_task.set(rootTask);

          this.doClose(task);
        }else{
          console.log("can't find folio from task.");
        }
      }
    });

  }

  findFolio(folio_id: string, folio: TaskVo){

    let ret: TaskVo | undefined;

    if(folio.folio_id === folio_id){
      ret = folio;
    }else if(folio.child?.length){
      for (let idx = 0; idx < folio.child.length; idx++) {
        const f = folio.child[idx];
        ret = this.findFolio(folio_id, f);

        if(ret) break;
      }
    }
    return ret;
  }

  setFileName = (evt: Event) => {
    this.state.update(x => {
      return {
        ...x,
        filename: evt.target
      };
    });
  };

  onHandlerChange = (id: any) => {

    console.log(id);
    const ug: UserGroupVo = {};
    const usr: UserAccountVo = {};

    const findNode = (key: string, nodes: Array<TreeNodeVo>): TreeNodeVo | null => {
      let ret: TreeNodeVo = {};
      for (const node of nodes) {
        if (node.key === key) {
          return node;
        }
        if (node.children?.length) {
          const found = findNode(key, node.children);
          if (found) {
            return found;
          }
        }
      }
      return null;
    };

    const item = findNode(id, this.handler());
    if(item){
      if(item.data.user_id){
        usr.user_id = item?.data?.user_id;
        usr.user_name = item?.data?.user_name;
      }else{
        ug.group_id = item?.data?.group_id;
        ug.group_name = item?.data?.group_name;
      }
    }

    this.request.update(r => {
      return {
        ...r,
        res_id: usr.user_id,
        res_name: usr.user_name,
        group_id: ug.group_id,
        group_name: ug.group_name
      };
    });

    console.log("onHandlerChange", this.request());
  };
}
