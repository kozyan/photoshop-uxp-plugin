import { Component, computed, OnInit, signal } from '@angular/core';
import { FolioItemVo, LayoutVo, TaskVo } from '../../../../service/@vo';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { AppService } from '../../../../service/app.service';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { NzTabChangeEvent } from 'ng-zorro-antd/tabs';
import { OpenLayoutRequest } from '../../typesetting/layout-opening/layout-opening.component';


export interface IOpenFolioItemState {
  open: boolean;
  folioItem: FolioItemVo;
  layout_id?: number;
  task?: TaskVo;
  oldVersionLayoutList?: Array<FolioItemVo>;
  templateLayoutList?: Array<LayoutVo>;
  version: number;
  s_version: string;
}
export type OpenFolioItemState = Partial<IOpenFolioItemState>;

export interface OpenFolioItemRequest {
  layout_id?: number;
  folioItem: FolioItemVo;
  serverFile?: string;
  isOldVersion?: boolean;
  isTemplate?: boolean;
  readonly: boolean;
}
@Component({
  selector: 'app-open-folio-item',
  templateUrl: './open-folio-item.component.html',
  styleUrls: ['./open-folio-item.component.css']
})
export class OpenFolioItemComponent implements OnInit {

  state = signal<OpenFolioItemState>({});

  loading = signal(false);
  // state = signal<LayoutOpeningState>({open: false},{equal:(a, b) => a.layout_id === b.layout_id});

  opening = signal(false);

  fileName = computed(() => {
    const name = this.state().folioItem?.real_filename;
    return name;
  });

  openLayoutReq = signal<OpenLayoutRequest>({
    serverFile: "",
    isOldVersion: false,
    isTemplate: true,//默认模板打开
    readonly: false
  });

  selectedTabIndex = signal(0);//默认模板打开
  allowToOpenLayout = computed(() => {
    if(this.openLayoutReq().isTemplate){ //选择模板
      const selectedIdx = (this.state().templateLayoutList || []).findIndex(x => x.selected);
      return selectedIdx > -1;
    }

    return true;
  });

  constructor(
    private modal: NzModalRef,
    private appService: AppService,
    private adobeService: AdobeService
  ) {
  }

  ngOnInit() {
    this.adobeService.BrowseOldVersion({item_id: this.state().folioItem?.item_id}).subscribe(x => {
      console.log("BrowserOldVersion", x);
      this.state.mutate(s => s.oldVersionLayoutList = (x.data || []));
    });

    this.adobeService.BrowseTemplate({layout_id: this.state().layout_id}).subscribe(x => {
      console.log("BrowseTemplate", x);
      this.state.mutate(s => s.templateLayoutList = (x.data || []));
    });

    this.selectedTabIndex.set(+(this.state().task?.progress_state||0) === 0 ? 0:1);

    this.openLayoutReq.mutate(x => {
      x.layout_id = this.state().layout_id;
      x.isTemplate = this.selectedTabIndex() === 0; //根据 tab 校正请求参数
      x.readonly = this.selectedTabIndex() === 2; //使用以前版本时，默认为只读
    });
  }

  doClose(){
    this.state.mutate(val => val.open = false);
    this.modal.close(this.state().folioItem);
    this.appService.Refresh();
  }

  doSure(evt: Event) {

    this.opening.set(true);
    this.appService.Refresh();

    const parm = {
      item_id: this.state().folioItem?.item_id,
      version: this.state().version,
      s_version: this.state().s_version,
    };
    console.log(parm);

    this.adobeService.OpenFolioItem(parm).subscribe(ret => {
      this.opening.set(false);

      console.log("response openFolioItem:", ret);
      this.doClose();
    });
  }

  // doHisSelectChanged(evt: FolioItemVo) {
  //   console.log("OpenFolioItem::doHisSelectChanged:", evt);

  //   this.state.mutate(x => {
  //     x.version = evt.version;
  //     x.s_version = evt.s_version;
  //   });
  // }
  doHisSelectChanged(evt: FolioItemVo) {
    console.log("OpenFolioItem::doHisSelectChanged:", evt);

    this.state.mutate(x => {
      x.version = evt.version;
      x.s_version = evt.s_version;
    });

    this.state().oldVersionLayoutList?.forEach(x => {
      if(x.version === evt.version && x.s_version === evt.s_version){
        x.selected = evt.selected;
      }else{
        x.selected = false;
      }
    });
  }

  doTabChanged(tab: NzTabChangeEvent) {
    if(tab.index === 0){ //当前版本
      this.openLayoutReq.mutate(x => {
        x.isTemplate = false;
        x.isOldVersion = true;
        x.readonly = false;
      });
    }else{ //历史版本
      this.openLayoutReq.mutate(x => {
        x.isTemplate = false;
        x.isOldVersion = true;
        x.readonly = true;
      });

    }

    this.selectedTabIndex.set(tab.index || 0);
  }

  doSelectTemplate(evt: LayoutVo){


    this.state().templateLayoutList?.forEach(x => {
      if(x.fullName === evt.fullName){
        x.selected = true;
      }else{
        x.selected = false;
      }
    });

    this.openLayoutReq.update(v => {
      return {
        ...v,
        isTemplate: true,
        serverFile: evt.fullName || "",
      }
    });

    this.appService.Refresh();
  }

  async doBrowseTemplateFile(evt: LayoutVo) {

    const ret = window.cep.fs.showOpenDialogEx(false, false, "選擇模板", evt.fullName||"~/Documents", ["indt","indd"],"Template(*.indt;*.indd)","OK");
    if(ret.data && ret.data.length > 0){

      console.log(ret.data);

      this.state().templateLayoutList?.forEach(x => {
        if(x.fullName === evt.fullName){
          x.selected = true;
          x.fullName = ret.data[0];
        }else{
          x.selected = false;
        }
      });

     evt.fullName = ret.data[0];

     this.openLayoutReq.mutate(x => {
        x.isTemplate = true;
        x.serverFile = evt.fullName || "";
      });

      this.appService.Refresh();

    }
  }
}
