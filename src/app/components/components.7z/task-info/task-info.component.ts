import { Component, ElementRef, OnDestroy, OnInit, ViewChild, ViewContainerRef, computed, effect, inject, signal } from '@angular/core';
import { FolioItemVo, ITaskVo, TaskUploadRequest, TaskVo } from '../../../service/@vo';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { AppService } from '../../../service/app.service';
import { AdobeService } from '../../../service/@base/adobe.service';
import { ActivatedRoute, Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { NzFormatEmitEvent, NzTreeComponent, NzTreeNode } from 'ng-zorro-antd/tree';
import { NzContextMenuService, NzDropdownMenuComponent } from 'ng-zorro-antd/dropdown';
import { IUploadFolioItemState, UploadFolioItemComponent } from './upload-folio-item/upload-folio-item.component';
import { OpenFolioItemComponent, OpenFolioItemRequest, OpenFolioItemState } from './open-folio-item/open-folio-item.component';
import { FolioItemFormComponent, FolioItemFormState } from './folio-item-form/folio-item-form.component';
import { toObservable } from '@angular/core/rxjs-interop';
import { Subject, interval } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ChangeOnhandComponent, ChangeOnHandeState, IChangeOnHandeState } from './change-onhand/change-onhand.component';

export interface TaskInfoState {
  grp_id?: string;
  task?: TaskVo;
  editing?: boolean;
}

@Component({
  selector: 'app-task-info',
  templateUrl: './task-info.component.html',
  styleUrls: ['./task-info.component.css']
})
export class TaskInfoComponent implements OnInit, OnDestroy {
  @ViewChild('pkgNodeTree', { static: false }) pkgNodeTree?: ElementRef;
  @ViewChild('tree', { static: false }) tree?: NzTreeComponent;

  state = signal<TaskInfoState>({});
  unsubscribe = new Subject<void>();
  private docCountInterval: any; // 定时器变量

  ma_number = computed(() => {
    if(this.state().task?.material_apply?.length){
      return `(${this.state().task!.material_apply![0].ma_id})`;
    }
    return "";

  });

  pkgNodes = signal<NzTreeNode[]>([]);

  currentFolioItem = inject(AppService).selected_FolioItem;
  // currentFolioItem = signal<FolioItemVo>({});
  currentFolioItemChanged$ = toObservable(this.currentFolioItem);

  folioItemCount = computed(() => {
    return this.appService.selected_task().folio_item?.length || 0;
  }, {equal: (a, b) => a == b});

  //选中的树节点(folio_item)
  selectedKeys: Array<string> = [];

  docCount = inject(AppService).docCount;

  constructor(
    private viewContainerRef: ViewContainerRef,
    private nzContextMenuService: NzContextMenuService,
    private route: ActivatedRoute,
    private router: Router,
    private appService: AppService,
    private adobeService: AdobeService,
    private modalService: NzModalService,
  ) {
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
    if (this.docCountInterval) {
      clearInterval(this.docCountInterval); // 清除定时器
    }
  }

  ngOnInit() {
    // 启动定时器，每隔5秒调用 GetDocCount 方法
    this.docCountInterval = interval(2000)
      .pipe(takeUntil(this.unsubscribe))
      .subscribe(() => {

        this.adobeService.GetDocCount({}).subscribe(x => {
          console.log("APP::TaskInfoComponent::GetDocCount", x);
          this.appService.docCount.set(x.data.docCount);
        });

      });

      // 新增：根据 path 查找对应的 folio_item 并设置为当前选中项
      const findFolioItem = (tasks: TaskVo[], targetId: string): FolioItemVo | undefined => {
        for (const task of tasks) {
          if (task.folio_item) {
            const foundItem = task.folio_item.find(item => item.item_id === targetId);
            if (foundItem) return foundItem;
          }
          if (task.child) {
            const foundInChild = findFolioItem(task.child, targetId);
            if (foundInChild) return foundInChild;
          }
        }
        return undefined;
      };

    this.route.queryParams.subscribe(async p => {
      this.appService.CurPageUrl("main/taskinfo");

      const grp_id = p["grp_id"];
      const task = this.appService.selected_task();

      this.state.set({ grp_id, task });

      this.pkgNodes.set(this.toTree([task]));

      console.log("#", grp_id);
      console.log(task);

      const item_id = p["item_id"];
      console.log("taskInfo::OnInit::item_id:", item_id);

      //导航到 taskinfo 后设置当前 folio_item
      const foundFolioItem = findFolioItem([task], item_id);
      if (foundFolioItem) {
        console.log("taskinfo::onDocChange::foundFolioItem:", foundFolioItem);
        this.currentFolioItem.set(foundFolioItem);
      }

      this.appService.Refresh();
    });

    this.adobeService.onDocChange().subscribe(ret => {
      console.log("open folio_item:", ret.data);

      const {item_id, path} = ret.data; // path 格式为 grp_id1:grp_id2:...:item_id
      const task = this.appService.selected_task();
      console.log("onDocChange", task);

      this.pkgNodes.set(this.toTree([task]));

      const foundFolioItem = findFolioItem([task], item_id);
      if (foundFolioItem) {
        console.log("taskinfo::onDocChange::foundFolioItem:", foundFolioItem);
        this.currentFolioItem.set(foundFolioItem);
      }

      this.appService.Refresh();
    });

    this.currentFolioItemChanged$.subscribe(async fi => {
      if(!fi.item_id) return;

      // 修改：递归清除 pkgNodes 中的所有节点选中状态
      this.pkgNodes.update(nodes => {
        const setUnselected = (nodeList: NzTreeNode[]) => {
          nodeList.forEach(node => {
            node.isSelected = false;
            if (node.children && node.children.length > 0) {
              setUnselected(node.children);
            }
          });
        };
        setUnselected(nodes);
        return nodes;
      });

      // 新增：在树中选中节点，并滚动到指定锚点
      const itemId = `${fi.item_id}`;
      if (itemId) {
        this.selectedKeys = [itemId];
        if(this.tree){
          this.tree.nzSelectedKeys = [...this.selectedKeys];
        }
      }

      setTimeout(() => {
        const element = this.pkgNodeTree?.nativeElement?.querySelector(`nz-tree-node-title[title='${fi.real_filename}']`);
        if (element) {
          element.scrollIntoView({
            behavior: 'smooth',
            block: 'nearest',
            inline: 'start'
          });

        }
      }, 1000); // 延迟100ms确保DOM更新

      this.appService.Refresh();
    });
  }

  goBack = () => {
    const returnUrl = this.appService.GoPrePage();
    this.router.navigate([returnUrl]);
  }

  toTree(tasks: TaskVo[]){
    let ret: Array<NzTreeNode|any> = [];

    tasks.forEach(x => {
      let children: Array<NzTreeNode|any> = [];

      let n = {
        key: x.grp_id!,
        title: x.grp_name!,
        grp_type: x.grp_type, //Folio || Folder || undefine
        data: x,
        isLeaf: false,
        expanded: true,
        children
      };

      if(x.folio_item?.length){ //增加 folio item
        let fi_children: Array<NzTreeNode|any> = [];

        x.folio_item.forEach(fi => {
          // 查找是否已存在相同key的节点
          const existingNode = children.find(child =>
            child.key === `${fi.item_id}`
          );

          if (existingNode) {
            // 更新现有节点
            existingNode.title = fi.real_filename;
            existingNode.data = fi;
          } else {
            // 新增节点
            let fn = {
              key: `${fi.item_id}`,
              title: fi.real_filename,
              data: fi,
              isLeaf: true,
            };
            fi_children.push(fn);
          }
        });

        children.push(...fi_children);
      }

      if(x.child?.length){ //增加子 pkg
        const sn = this.toTree(x.child);
        children.push(...sn);
      }

      ret.push(n);
    });

    return ret;
  }

  // onBack = () => this.router.navigate([this.returnUrl]);

  doSelectedPkg(event: NzFormatEmitEvent) {
    // event.selectedKeys = [];
    // this.selectedKeys = [];
    // this.selectedKeys.push(event!.node!.key);
    // console.log(event, this.selectedKeys);
  }

  openFolder(evt: any) {

  }

  contextMenu(evt: MouseEvent, menu: NzDropdownMenuComponent, folioItem: FolioItemVo) {
    console.log(folioItem);

    const ext = ["ai","ait","pdf","eps","svg","svgz"];
    const fileExt = (folioItem?.file_extend || "").toLowerCase();
    if(ext.includes(fileExt)){
      this.currentFolioItem.set(folioItem);

      this.nzContextMenuService.create(evt, menu);
    }
  }

  uploadFolioItem(data: TaskVo|FolioItemVo) {

    if(this.docCount() === 0) return;

    const dlg = this.modalService.create<UploadFolioItemComponent, IUploadFolioItemState>({
      nzContent: UploadFolioItemComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null,
    });

    dlg.componentInstance?.state.set({
      task: data||{},
      folioItem: {},
    });

    this.appService.Refresh();

  }

  openFile = (folioItem: FolioItemVo) => {

    const dlg = this.modalService.create<OpenFolioItemComponent, OpenFolioItemState>({
      nzContent: OpenFolioItemComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null
    });
    dlg.componentInstance?.state.set({open: true, folioItem});
    dlg.afterClose.subscribe((x:OpenFolioItemRequest) => {
      console.log(x);

      this.appService.Refresh();
    });

    this.appService.Refresh();
  }

  modifyFolioItem = (folioItem: FolioItemVo) => {
    console.log("modifyFolioItem", folioItem);

    if(this.docCount() === 0) return;

    const dlg = this.modalService.create<FolioItemFormComponent, FolioItemFormState>({
      nzContent: FolioItemFormComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null
    });
    dlg.componentInstance?.state.set({open: true, folioItem});
    dlg.afterClose.subscribe((x:OpenFolioItemRequest) => {
      console.log(x);

      this.appService.Refresh();
    });

    this.appService.Refresh();
  }

  removeFolioItem = (data: FolioItemVo) => {
    const msg = `確定要移除檔案 ${data.real_filename} 吗？`;
    this.modalService.confirm({
      nzTitle: '移除檔案',
      nzContent: msg,
      nzOkText: '確定',
      nzCancelText: '取消',
      nzOnOk: () => {
        const parm = {item_id: data.item_id};
        this.adobeService.DeleteFolioItem(parm).subscribe(ret => {
          if (ret.data) {
            const task = this.appService.selected_task();

            // 递归删除folio_item
            const removeItemFromTask = (taskList: TaskVo[]) => {
              taskList.forEach(task => {
                if (task.folio_item) {
                  task.folio_item = task.folio_item.filter(item => item.item_id !== data.item_id);
                }
                if (task.child) {
                  removeItemFromTask(task.child);
                }
              });
            };

            removeItemFromTask([task]);

            this.pkgNodes.set(this.toTree([task]));
            // 清除当前选中的树节点
            if(this.tree){
              this.tree.nzSelectedKeys = [];
            }
            this.appService.Refresh();
          }else{
            this.modalService.error({nzTitle: '',nzContent: '移除檔案失敗！'});
            this.appService.Refresh();
          }
        });
      }
    });
  }

  changeOnHand = (data: FolioItemVo) => {

    const dlg = this.modalService.create<ChangeOnhandComponent, ChangeOnHandeState>({
      nzContent: ChangeOnhandComponent,
      nzViewContainerRef: this.viewContainerRef,
      nzClosable: false,
      nzFooter: null,
    });

    dlg.componentInstance?.state.set({
      task: data||{},
      folioItem: data,
      isDelete: false
    });
    dlg.afterClose.subscribe((x:ChangeOnHandeState) => {
      console.log("TaskInfo::changeOnHand", x);
      if (x?.isDelete) {
        const task = this.appService.selected_task();

        // 递归删除folio_item
        const removeItemFromTask = (taskList: TaskVo[]) => {
          taskList.forEach(task => {
            if (task.folio_item) {
              task.folio_item = task.folio_item.filter(item => item.item_id !== data.item_id);
            }
            if (task.child) {
              removeItemFromTask(task.child);
            }
          });
        };

        removeItemFromTask([task]);

        this.pkgNodes.set(this.toTree([task]));
        // 清除当前选中的树节点
        if(this.tree){
          this.tree.nzSelectedKeys = [];
        }
      }
      this.appService.Refresh();
    });

    this.appService.Refresh();

  }
}
