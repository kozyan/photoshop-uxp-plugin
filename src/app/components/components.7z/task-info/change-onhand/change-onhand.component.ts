import { Component, OnInit, computed, inject, signal } from '@angular/core';
import { ApplyItemInfoVo, ChangeOnhandRequest, FolioItemVo, MaterialApplyVo, TaskFolioResDtlVo, TaskUploadRequest, TaskVo, TreeNodeVo, UserAccountVo } from '../../../../service/@vo';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { AppService } from '../../../../service/app.service';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { NzTreeNode } from 'ng-zorro-antd/tree';
import { UserGroupVo } from '../../../../models/user_group';
import { NotifyService, NotifyType } from '../../../../service/notify.service';

export interface IChangeOnHandeState {
  task: TaskVo,
  folioItem: FolioItemVo,
  isDelete?: boolean
}
export type ChangeOnHandeState = Required<IChangeOnHandeState>;

@Component({
  selector: 'app-change-onhand',
  templateUrl: './change-onhand.component.html',
  styleUrls: ['./change-onhand.component.css']
})
export class ChangeOnhandComponent implements OnInit {

  state = signal<ChangeOnHandeState>({task:{}, folioItem:{}, isDelete: false });
  request = signal<ChangeOnhandRequest>({});
  taskFolioResDtl = signal<Array<TaskFolioResDtlVo>>([]);

  message = inject(NotifyService).message;

  handler = signal<any[]>([]);

  cur_task = computed(() => {
    return this.state().task || {
      filename: "",
      file_info: ""
    };
  });

  sss = computed(() => {
    return this.state().folioItem.res_id || this.state().folioItem.group_id;
  });

  selectedHandler = signal("");
  uploading = signal(false);

  frd_list: Array<TaskFolioResDtlVo> = [];

  constructor(
    private modal: NzModalRef,
    private appService: AppService,
    private adobeService: AdobeService,
  ) { }

  ngOnInit() {

    //如果是打开旧的 folio_item
    if(this.state().folioItem.item_id){
      this.request.update(req => {
        return {
          ...req,
          item_id: this.state().folioItem.item_id,
          tfr_id: this.state().folioItem.tfr_id,
          res_id: this.state().folioItem.res_id,
          res_name: this.state().folioItem.res_name,
          group_id: this.state().folioItem.group_id,
          group_name: this.state().folioItem.group_name,
        }
      });
    }

    console.log("ChangeOnhand::folioItem", this.state());
    const tfr_id = this.state().folioItem.tfr_id || '';
    this.doStepChanged(tfr_id);

  }

  doStepChanged(tfr_id: string){

    const parm = {tfr_id: this.request().tfr_id};
    this.adobeService.GetTaskFolioResDtl(parm).subscribe(ret => {
      console.log(ret);

      if(ret.data.length){
        this.frd_list = ret.data as Array<TaskFolioResDtlVo>;

        const node_list: Array<TreeNodeVo> = [];

        this.frd_list.forEach((current, idx) => {
          if(current.user){
            if(!node_list.some(item => item.key === current.user?.user_id)){
              node_list.push({
                key: current.user.user_id,
                title: current.user.user_name,
                isLeaf: true,
                data: current.user
              });
            }
          }else if(current.group){
            if(!node_list.some(item => item.key === current.group?.group_id)){

              const children: Array<TreeNodeVo> = [];
              if(current.group.users?.length){
                current.group.users.forEach(u => {
                  children.push({
                    key: u.user_id,
                    title: u.user_name,
                    isLeaf: true,
                    data: u
                  });
                });
              }

              node_list.push({
                key: current.group.group_id,
                title: current.group.group_name,
                isLeaf: false,
                expanded: true,
                data: current.group,
                children
              });
            }

          }
        });
        this.handler.set(node_list);

        // console.log(data);

        this.selectedHandler.set("");
      }
    });

    //更新 ft_id
    const tfr = this.state().task.task_folio_resources?.find(x => x.tfr_id === tfr_id);
    this.request.update(req => {
      return {
        ...req,
        ft_id: tfr?.ft_id,
      }
    });
  }

  /**
   * @deprecated 该方法已经作废
   *
   * @param {Array<TaskFolioResDtlVo>} list
   * @return {*}
   * @memberof UploadFolioItemComponent
   */
  toTreeNodeList(list: Array<TaskFolioResDtlVo>){
    const ret: Array<TreeNodeVo> = [];

    list.forEach(x => {
      const children: Array<TreeNodeVo> = [];

      if(x.user_list?.length){
        x.user_list.forEach(u => {
          children.push({
            key: u.user_id,
            title: u.user_name,
            isLeaf: true,
            data: u
          });
        });
      }

      ret.push({
        key: x.hr_id?.toString(),
        title: x.hr_name,
        expanded: true,
        children: children,
        data: x
      });
    });

    return ret;
  }

  doClose(parm?: any){
    this.modal.close(parm);
    this.appService.Refresh();
  }

  /**
   *确定上传后 api 会返回空值，并触发 DocChange 事件
   *所以要在 DocChange 的事件中获取以下信息：
   * fileName: "illustrator测试.ai", is_material_apply: false, item_id: "6251838A-4825-443A-9297-E36E2D77A0D9"
   *
   * @param {Event} event
   * @memberof UploadFolioItemComponent
   */
  doSure(event: Event){

    console.log(this.request());

    const parm: TaskUploadRequest = this.request();

    this.uploading.set(true);
    this.appService.Refresh();

    this.adobeService.ChangeOnHand(parm).subscribe(ret => {
      console.log("response Change Onhand: ", ret);

      this.uploading.set(false);
      this.appService.Refresh();

      const userInfo = this.appService.userInfo();
      const group = this.handler().find(g => g.data.group_id == this.request().group_id);
      console.log("选择的处理组：", group);

      //检查用户是否在该群组内
      let belongTo = false;
      if(group?.children){
        belongTo = group.children.find((n:TreeNodeVo) => n.key === userInfo.user_id)
      }

      //如果 change onhand 为用户所在的组，则不用删除节点
      if(group && belongTo){
        this.doClose(this.state());
      }else if(this.request().res_id === userInfo.user_id){
        this.doClose(this.state());
      }else{
        this.state.update(ret => {
          ret.isDelete = true;
          return ret;
        });
        this.doClose(this.state());
      }

    });

  }

  findFolio(folio_id: string, folio: TaskVo){

    let ret: TaskVo | undefined;

    if(folio.folio_id === folio_id){
      ret = folio;
    }else if(folio.child?.length){
      for (let idx = 0; idx < folio.child.length; idx++) {
        const f = folio.child[idx];
        ret = this.findFolio(folio_id, f);

        if(ret) break;
      }
    }
    return ret;
  }

  setFileName = (evt: Event) => {
    this.state.update(x => {
      return {
        ...x,
        filename: evt.target
      };
    });
  };

  onHandlerChange = (id: any) => {

    console.log(id);
    const ug: UserGroupVo = {};
    const usr: UserAccountVo = {};

    const findNode = (key: string, nodes: Array<TreeNodeVo>): TreeNodeVo | null => {
      for (const node of nodes) {
        if (node.key === key) {
          return node;
        }
        if (node.children?.length) {
          const found = findNode(key, node.children);
          if (found) {
            return found;
          }
        }
      }
      return null;
    };
    const item = findNode(id, this.handler());
    if(item){
      if(item.data.user_id){
        usr.user_id = item?.data?.user_id;
        usr.user_name = item?.data?.user_name;
      }else{
        ug.group_id = item?.data?.group_id;
        ug.group_name = item?.data?.group_name;
      }
    }

    this.request.update(r => {
      return {
        ...r,
        res_id: usr.user_id,
        res_name: usr.user_name,
        group_id: ug.group_id,
        group_name: ug.group_name
      };
    });

    console.log("onHandlerChange", this.request());
  };
}
