import { Component, computed, effect, OnInit, signal } from '@angular/core';
import { NzModalRef } from 'ng-zorro-antd/modal';
import { AppService } from '../../../../service/app.service';
import { AdobeService } from '../../../../service/@base/adobe.service';
import { FolioItemVo } from '../../../../service/@vo';

export interface FolioItemFormState {
  open: boolean;
  folioItem?: FolioItemVo;
  s_version?: number;
  ver_remark?: string;
}

@Component({
  selector: 'app-folio-item-form',
  templateUrl: './folio-item-form.component.html',
  styleUrls: ['./folio-item-form.component.css']
})
export class FolioItemFormComponent implements OnInit {

  state = signal<FolioItemFormState>({open: false});
  updating = signal(false);

  fileName = computed(() => {
    const name = this.state().folioItem?.real_filename;
    return name;
  });

  fullPath = computed(() => {
    const subject = (this.state().folioItem?.subject||"").replaceAll("\\", "/");
    const sub_path = (this.state().folioItem?.ng_subpath_full||"").replaceAll("\\", "/");
    const path = `${subject}/${sub_path}`
    return path;
  });

  constructor(
    private modal: NzModalRef,
    private appService: AppService,
    private adobeService: AdobeService,
  ) {
    effect(() => {
      console.log("the state:", this.state());
    });
  }

  ngOnInit() {

  }

  doClose(){
    this.state.mutate(val => val.open = false);
    this.modal.close();
    this.appService.Refresh();
  }

  doSure(evt: Event) {
    this.updating.set(true);

    const parm = {
      item_id: this.state().folioItem?.item_id,
      ver_remark: this.state().ver_remark,
      s_version: this.state().folioItem?.s_version
    };
    this.adobeService.UpdateFolioItemVersion(parm).subscribe(ret => {
      this.updating.set(false);

      if(ret.data){ //有数据返回
        this.modal.close();
      }else{
        console.log("UpdateFolioItemVersion 失败:", ret);
      }

      this.appService.Refresh();
    });
  }
}
