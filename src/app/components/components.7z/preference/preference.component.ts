import { Component, OnInit, ViewChild, WritableSignal, effect, signal } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdobeService } from '../../../service/@base/adobe.service';
import { PreferenceVo } from '../../../service/@vo/PreferenceVo';
import { AppService } from '../../../service/app.service';
import { PluginInfoVo } from '../../../service/@vo/PluginInfoVo';

import { Observable, firstValueFrom, lastValueFrom, of } from 'rxjs';

@Component({
  selector: 'app-preference',
  templateUrl: './preference.component.html',
  styleUrls: ['./preference.component.css']
})
export class PreferenceComponent implements OnInit {

  returnUrl = "";

  vo = signal<PreferenceVo>({});
  parameters = signal({});

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private appService: AppService,
    private adobeService: AdobeService
  ) {
    this.vo = this.appService.preference;
   }

  ngOnInit() {
    this.route.queryParams.subscribe(async p => {
      if(!p["returnUrl"]) return;

      this.returnUrl = p["returnUrl"];

      const ret = await firstValueFrom(this.adobeService.GetSystemParameters())
      this.vo.set(ret.data);
      console.log(this.vo());
    });
  }

  onBack = () => this.router.navigate([this.returnUrl]);

  browser = () => {

		let ret = window.cep.fs.showOpenDialogEx(false, true, "Select folder", "~/Documents", ["*.*"], "All files", "OK");
    // console.log(result);
    if(ret.data && ret.data.length > 0){
     this.vo.mutate(x => x.savepath = ret.data[0]);
     this.adobeService.UpdateSystemParameters(this.vo()).subscribe(x => {
      console.log(x);
     });
    }
  };
}
