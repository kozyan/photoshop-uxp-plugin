import { NgModule } from '@angular/core';
import { CustomComponentModule } from '../components/custom-component.module';
import { MainComponent } from './main.component';

@NgModule({
  imports: [
   CustomComponentModule,
   MainComponent,
  ],
  declarations: []
})
export class MainModule { }
